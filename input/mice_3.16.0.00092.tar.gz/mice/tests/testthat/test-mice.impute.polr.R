context("polr")

# following halts with
# "Error in apply(draws, 2, sum) : dim(X) must have a positive length"
# imp1 <- mice(boys, blocks = list("gen"), print = FALSE, m = 1, maxit = 1)
